<template>
    <div class="toolbar">
    	<div class="toobar_inner">
    		<ul class="main_menu">
    			
    		</ul>
    		<div class="menu-root">
    			<h2>
    				教程
					<select class="version_select">
			            <option value="SELF" selected="">2.x</option>
			            <option value="v1">1.0</option>
			        </select>
    			</h2>
				<ul class="menu_root">
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
					<li>
						<h3>基础</h3>
					</li>
					<li><h3>安装</h3></li>
					<li>
						介绍
						<ul class="menu_sub">
							<li>这是什么</li>
						</ul>
					</li>
				</ul>
    		</div>
    	</div>
    </div>
</template>

<script>
    
</script>

<style rel="stylesheet">

</style>