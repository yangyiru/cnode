<template>
  <div id="app">
      <router-view/>
  </div>
</template>

<script>
// import toolbar from '@/components/toolbar'
export default {
  name: 'app'
}
</script>

<style>

</style>
